# Here are some ideas for readers!

1. See the source in read-It/
2. Make your conclusions!
3. Enjoy it!

@ Most of this source was/is dedicated to Real Python dot Com
