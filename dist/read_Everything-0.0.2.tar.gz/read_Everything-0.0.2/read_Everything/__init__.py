# __init__.py

# --version of the realpython-reader package
__version__ = "0.0.2"
